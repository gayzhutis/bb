<?php

$_lang['moddevtools'] = 'modDevTools';
$_lang['moddevtools_chunks_intro'] = 'You can directly edit the chunks contained in the template.';
$_lang['moddevtools_snippets_intro'] = 'You can directly edit the snippets contained in the template.';
$_lang['moddevtools_templates_intro'] = 'You can directly edit the templates containing this chunk.';
$_lang['moddevtools_grid_actions'] = 'Actions';
$_lang['moddevtools_template_change'] = 'Change template';