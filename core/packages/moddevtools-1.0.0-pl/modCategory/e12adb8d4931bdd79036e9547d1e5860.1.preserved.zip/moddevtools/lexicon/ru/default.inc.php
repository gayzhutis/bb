<?php

$_lang['moddevtools'] = 'modDevTools';
$_lang['moddevtools_chunks_intro'] = 'Вы можете напрямую редактировать чанки, содержащиеся в шаблоне.';
$_lang['moddevtools_snippets_intro'] = 'Вы можете напрямую редактировать сниппеты, содержащиеся в шаблоне.';
$_lang['moddevtools_templates_intro'] = 'Вы можете напрямую редактировать шаблоны, которые содержат этот чанк.';
$_lang['moddevtools_grid_actions'] = 'Действия';
$_lang['moddevtools_template_change'] = 'Изменить шаблон';
