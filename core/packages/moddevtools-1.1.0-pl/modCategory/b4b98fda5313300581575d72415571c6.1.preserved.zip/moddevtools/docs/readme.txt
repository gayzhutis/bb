--------------------
modDevTools
--------------------
Author: Kireev Vitaly <kireevvit@gmail.com>
--------------------

Rapid site development helper for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/argnist/modDevTools/issues