<?php
require_once (dirname(dirname(__FILE__)) . '/msequery.class.php');
class mseQuery_mysql extends mseQuery {}