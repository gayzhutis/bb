miniShop2.plugin.pluginname = {
            getFields: function(config) {
                        return {
                            manufacturer: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_manufacturer_help')},
                            category: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_category_help')},
                            subcategs: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_subcategs_help')},
                            sport: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_sport_help')},
                            ingridients: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_ingridients_help')},
                            goal: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_goal_help')},
                            packing: {xtype: 'numberfield', decimalPrecision: 1, description: '<b></b><br />'+_('ms2_product_packing_help')},
                            packing_unit: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_packing_unit_help')},
                            number_of_servings: {xtype: 'numberfield', decimalPrecision: 1, description: '<b></b><br />'+_('ms2_product_number_of_servings_help')},
                            taste: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_taste_help')},
                            composition: {xtype: 'htmleditor', description: '<b></b><br />'+_('ms2_product_composition_help')},
                            recommendations: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_recommendations_help')},
                            gender: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_gender_help')},
                            barcode: {xtype: 'minishop2-combo-autocomplete', description: '<b></b><br />'+_('ms2_product_barcode_help')}
                                                }
            }
            ,getColumns: function() {
                        return {
                                    manufacturer: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'manufacturer'}},
                                    category: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'category'}},
                                    subcategs: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'subcategs'}},
                                    sport: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'sport'}},
                                    ingridients: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'ingridients'}},
                                    goal: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'goal'}},
                                    packing: {width:50, sortable:false, editor: {xtype:'numberfield', decimalPrecision: 1, name: 'packing'}},
                                    packing_unit: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'packing_unit'}},
                                    number_of_servings: {width:50, sortable:false, editor: {xtype:'numberfield', decimalPrecision: 1, name: 'number_of_servings'}},
                                    taste: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'taste'}},
                                    composition: {width:450, sortable:false, editor: {xtype:'htmleditor', name: 'composition'}},
                                    recommendations: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'recommendations'}},
                                    gender: {width:50, sortable:false, editor: {xtype:'minishop2-combo-autocomplete', name: 'gender'}},
                        }
            }
};