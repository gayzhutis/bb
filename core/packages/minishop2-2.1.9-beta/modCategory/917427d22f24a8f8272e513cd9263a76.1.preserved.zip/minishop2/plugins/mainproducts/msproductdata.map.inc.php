<?php
return array(
           'fields' => array(
                        'manufacturer' => NULL,
                        'category' => NULL,
                        'subcategs' => NULL,
                        'sport' => NULL,
                        'ingridients' => NULL,
                        'goal' => NULL,
                        'packing' => NULL,
                        'packing_unit' => NULL,
                        'number_of_servings' => NULL,
                        'taste' => NULL,
                        'composition' => NULL,
                        'recommendations' => NULL,
                        'barcode' => NULL,
                        'gender' => NULL
            )             
           ,'fieldMeta' => array(
                        'manufacturer' => array(
                                          'dbtype' => 'varchar'
                                            ,'precision' => '255'
                                            ,'phptype' => 'string'
                                            ,'null' => true
                                            ,'default' => NULL
                                ),
                        'category' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'subcategs' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'sport' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'ingridients' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'goal' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'packing' => array(
                                  'dbtype' => 'int',
                                  'precision' => '6',                                  
                                  'phptype' => 'integer',
                                  'null' => false  
                        ),
                        'packing_unit' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'number_of_servings' => array(
                                  'dbtype' => 'int',
                                  'precision' => '4',                                  
                                  'phptype' => 'integer',
                                  'null' => false 
                        ),
                        'taste' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'composition' => array(
                                  'dbtype' => 'mediumtext'                         
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        ),
                        'gender' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '20'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        )
                        ,
                        'recommendations' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '255'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        )
                         ,
                        'barcode' => array(
                                  'dbtype' => 'varchar'
                                    ,'precision' => '50'
                                    ,'phptype' => 'string'
                                    ,'null' => true
                                    ,'default' => NULL
                        )
            )
            ,'indexes' => array(
                        'category' => array (
                                    'alias' => 'category'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'subcategs' => array (
                                    'alias' => 'subcategs'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'sport' => array (
                                    'alias' => 'sport'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'ingridients' => array (
                                    'alias' => 'ingridients'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'goal' => array (
                                    'alias' => 'goal'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'packing' => array (
                                    'alias' => 'packing'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'packing_unit' => array (
                                    'alias' => 'packing_unit'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'number_of_servings' => array (
                                    'alias' => 'number_of_servings'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'taste' => array (
                                    'alias' => 'taste'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'composition' => array (
                                    'alias' => 'composition'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       ),
                       'gender' => array (
                                    'alias' => 'gender'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       )
                       ,
                       'recommendations' => array (
                                    'alias' => 'recommendations'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       )
                       ,
                       'barcode' => array (
                                    'alias' => 'barcode'
                                    ,'primary' => false
                                    ,'unique' => false
                                    ,'type' => 'BTREE'
                                    ,'columns' => array (
                                                'action' => array (
                                                            'length' => ''
                                                            ,'collation' => 'A'
                                                           ,'null' => false
                                                )
                                    )
                       )
            )
);