<?php
require_once (dirname(dirname(__FILE__)) . '/msdelivery.class.php');
class msDelivery_mysql extends msDelivery {}