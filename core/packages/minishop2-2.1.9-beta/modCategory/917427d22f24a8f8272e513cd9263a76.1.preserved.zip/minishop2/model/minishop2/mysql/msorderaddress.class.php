<?php
require_once (dirname(dirname(__FILE__)) . '/msorderaddress.class.php');
class msOrderAddress_mysql extends msOrderAddress {}