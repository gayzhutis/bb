<?php
require_once (dirname(dirname(__FILE__)) . '/mscategorymember.class.php');
class msCategoryMember_mysql extends msCategoryMember {}