<?php
$hook->addError('fullname','Please use a real name.');
return false;
