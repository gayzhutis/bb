<?php
class msOrderStatus extends xPDOSimpleObject {}