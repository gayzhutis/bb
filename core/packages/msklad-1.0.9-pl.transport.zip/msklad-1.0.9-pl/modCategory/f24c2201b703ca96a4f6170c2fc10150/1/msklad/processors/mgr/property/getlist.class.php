<?php

class mSkladPropertyGetListProcessor extends modObjectGetListProcessor {
	public $classKey = 'mSkladProductProperty';
	public $defaultSortField = 'id';
	public $defaultSortDirection = 'ASC';
}

return 'mSkladPropertyGetListProcessor';