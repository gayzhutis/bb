<?php
require_once (dirname(dirname(__FILE__)) . '/mskladproductproperty.class.php');
class mSkladProductProperty_mysql extends mSkladProductProperty {}