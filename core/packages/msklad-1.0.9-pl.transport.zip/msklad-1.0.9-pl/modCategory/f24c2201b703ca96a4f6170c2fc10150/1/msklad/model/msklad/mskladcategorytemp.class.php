<?php
class mSkladCategoryTemp extends xPDOSimpleObject {}