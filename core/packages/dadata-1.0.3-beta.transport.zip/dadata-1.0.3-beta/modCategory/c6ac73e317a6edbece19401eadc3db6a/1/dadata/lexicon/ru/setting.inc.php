<?php

$_lang['area_dadata_main'] = 'Основные';

$_lang['setting_dadata_apiToken'] = 'API ключ';
$_lang['setting_dadata_apiToken_desc'] = '';

$_lang['setting_dadata_apiSecret'] = 'Секретный ключ для стандартизации';
$_lang['setting_dadata_apiSecret_desc'] = '';
