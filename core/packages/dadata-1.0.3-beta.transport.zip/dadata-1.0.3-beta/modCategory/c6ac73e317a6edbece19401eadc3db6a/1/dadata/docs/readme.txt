--------------------
DaData
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------

DaData for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/vgrish/dadata/issues