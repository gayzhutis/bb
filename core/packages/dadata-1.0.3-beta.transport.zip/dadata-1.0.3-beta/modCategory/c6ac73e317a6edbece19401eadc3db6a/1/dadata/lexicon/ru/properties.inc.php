<?php

$_lang['dadata_prop_apiMode'] = 'Режим работы.';
$_lang['dadata_prop_apiToken'] = 'API ключ.';
$_lang['dadata_prop_apiSecret'] = 'Секретный ключ для стандартизации.';
$_lang['dadata_prop_suggestions'] = 'Строка параметров подсказок, закодированная в JSON.';
$_lang['dadata_prop_actionUrl'] = 'Коннектор для обработки ajax запросов.';
$_lang['dadata_prop_selector'] = 'Имя CSS класса, который будеи использован как jQuery селектор при выборе контейнера для поиска input.';
$_lang['dadata_prop_objectName'] = 'Имя объекта для инициализации в подключаемом javascript. По умолчанию "dadata".';
$_lang['dadata_prop_frontendCss'] = 'Файл с css стилями для подключения на фронтенде.';
$_lang['dadata_prop_frontendJs'] = 'Файл с javascript для подключения на фронтенде.';
$_lang['dadata_prop_jqueryJs'] = 'Файл с jquery.js для подключения на фронтенде.';

