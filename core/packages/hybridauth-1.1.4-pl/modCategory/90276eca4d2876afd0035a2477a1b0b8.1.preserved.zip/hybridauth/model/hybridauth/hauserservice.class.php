<?php
class haUserService extends xPDOSimpleObject {}