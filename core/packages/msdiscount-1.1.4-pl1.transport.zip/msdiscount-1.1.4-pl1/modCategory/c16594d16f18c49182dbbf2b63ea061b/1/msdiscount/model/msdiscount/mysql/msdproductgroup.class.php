<?php
require_once (dirname(dirname(__FILE__)) . '/msdproductgroup.class.php');
class msdProductGroup_mysql extends msdProductGroup {}