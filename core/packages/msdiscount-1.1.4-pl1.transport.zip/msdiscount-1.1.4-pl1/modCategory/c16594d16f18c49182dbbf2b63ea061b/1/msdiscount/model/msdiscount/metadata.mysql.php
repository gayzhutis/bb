<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'msdSale',
    1 => 'msdCouponGroup',
    2 => 'msdCoupon',
    3 => 'msdUserGroup',
    4 => 'msdProductGroup',
  ),
  'xPDOObject' => 
  array (
    0 => 'msdSaleMember',
  ),
);