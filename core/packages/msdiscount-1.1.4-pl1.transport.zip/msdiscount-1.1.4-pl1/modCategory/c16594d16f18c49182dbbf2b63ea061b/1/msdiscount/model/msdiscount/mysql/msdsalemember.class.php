<?php
require_once (dirname(dirname(__FILE__)) . '/msdsalemember.class.php');
class msdSaleMember_mysql extends msdSaleMember {}