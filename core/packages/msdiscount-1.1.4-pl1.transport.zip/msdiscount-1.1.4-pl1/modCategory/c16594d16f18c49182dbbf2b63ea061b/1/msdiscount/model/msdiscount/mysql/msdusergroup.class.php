<?php
require_once (dirname(dirname(__FILE__)) . '/msdusergroup.class.php');
class msdUserGroup_mysql extends msdUserGroup {}