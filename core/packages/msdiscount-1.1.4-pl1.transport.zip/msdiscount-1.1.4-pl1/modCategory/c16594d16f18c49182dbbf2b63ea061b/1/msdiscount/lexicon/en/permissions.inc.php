<?php

$_lang['msdiscount_save'] = 'Allows to create or update discounts of miniShop2';
$_lang['msdiscount_view'] = 'Allows to view properties of discounts of miniShop2';