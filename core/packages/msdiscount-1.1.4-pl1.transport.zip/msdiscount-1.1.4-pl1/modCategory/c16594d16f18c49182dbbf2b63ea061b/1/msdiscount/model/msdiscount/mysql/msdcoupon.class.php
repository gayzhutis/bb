<?php
require_once (dirname(dirname(__FILE__)) . '/msdcoupon.class.php');
class msdCoupon_mysql extends msdCoupon {}