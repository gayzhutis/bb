<?php
require_once (dirname(dirname(__FILE__)) . '/msdcoupongroup.class.php');
class msdCouponGroup_mysql extends msdCouponGroup {}