--------------------
msDiscount
--------------------
Author: Vasiliy Naumkin <bezumkin@yandex.ru>
--------------------

Discount system for miniShop2.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/bezumkin/msDiscount/issues
