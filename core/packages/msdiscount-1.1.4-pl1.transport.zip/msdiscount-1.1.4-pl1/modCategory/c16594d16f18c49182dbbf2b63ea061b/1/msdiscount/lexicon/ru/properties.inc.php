<?php

$_lang['msdiscount_prop_id'] = 'Id товара для вывода скидки и времени действия акции.';
$_lang['msdiscount_prop_sale'] = 'Список акций для вывода, через запятую.';
$_lang['msdiscount_prop_tpl'] = 'Чанк оформления для вывода результата работы сниппета.';
$_lang['msdiscount_prop_frontend_css'] = 'Файл с css стилями для подключения на фронтенде.';
$_lang['msdiscount_prop_frontend_js'] = 'Файл с javascript для подключения на фронтенде.';