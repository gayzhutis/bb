<?php
class msdProductGroup extends xPDOSimpleObject {}