<?php
require_once (dirname(dirname(__FILE__)) . '/msdsale.class.php');
class msdSale_mysql extends msdSale {}