<?php
class mSkladProductTemp extends xPDOSimpleObject {}