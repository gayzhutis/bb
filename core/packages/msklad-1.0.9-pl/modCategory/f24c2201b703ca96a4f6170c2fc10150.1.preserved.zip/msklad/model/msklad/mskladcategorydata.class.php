<?php
class mSkladCategoryData extends xPDOObject {}