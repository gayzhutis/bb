<?php
require_once (dirname(dirname(__FILE__)) . '/mskladproducttemp.class.php');
class mSkladProductTemp_mysql extends mSkladProductTemp {}