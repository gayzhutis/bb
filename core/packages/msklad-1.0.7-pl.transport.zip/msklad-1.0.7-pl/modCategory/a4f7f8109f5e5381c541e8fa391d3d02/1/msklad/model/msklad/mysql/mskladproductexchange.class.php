<?php
require_once (dirname(dirname(__FILE__)) . '/mskladproductexchange.class.php');
class mSkladProductExchange_mysql extends mSkladProductExchange {}